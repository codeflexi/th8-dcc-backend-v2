from __future__ import annotations

from datetime import date, datetime
from typing import Any, Dict, List, Optional


class DecisionEngine:
    """
    Rule-based Decision Engine (Phase 4 compatible)

    Guarantees:
    - violations[] matches Violation schema
    - case fields align with CaseDetail
    - audit events are UI-safe
    """

    def __init__(self, policy: Dict[str, Any], audit_repo: Optional[Any] = None):
        self.policy = policy
        self.audit_repo = audit_repo

    # =========================================================
    # Audit helper
    # =========================================================
    def _audit(self, case_id: str, event_type: str, payload: Dict[str, Any]) -> None:
        if not self.audit_repo or not case_id:
            return

        try:
            self.audit_repo.append_event(
                case_id=case_id,
                event_type=event_type,
                actor="system",
                payload=payload,
            )
        except Exception:
            # audit must never break decision flow
            pass

    # =========================================================
    # Main evaluate
    # =========================================================
    def evaluate(self, case: Dict[str, Any]) -> Dict[str, Any]:
        case_id = case.get("case_id") or case.get("id")
        violations: List[Dict[str, Any]] = []

        # ---------- Rule 1: Price Deviation ----------
        v = self._check_price_deviation(case)
        self._audit_rule(case_id, "R-01", "Price deviation vs contract", case, v)
        violations.extend(v)

        # ---------- Rule 2: Amount Threshold ----------
        v = self._check_amount_threshold(case)
        self._audit_rule(case_id, "R-02", "Amount exceeds approval threshold", case, v)
        violations.extend(v)

        # ---------- Rule 3: Vendor Mismatch ----------
        v = self._check_vendor_mismatch(case)
        self._audit_rule(case_id, "R-03", "Vendor mismatch", case, v)
        violations.extend(v)

        # ---------- Rule 4: Contract Validity ----------
        v = self._check_contract_validity(case)
        self._audit_rule(case_id, "R-04", "Contract validity", case, v)
        violations.extend(v)

        # =================================================
        # Final decision
        # =================================================
        if violations:
            case["status"] = "PENDING"
            case["violations"] = violations
            case["pending_reason"] = self._build_pending_reason(violations)

            self._audit(
                case_id,
                "CASE_PENDING",
                {
                    "status": case["status"],
                    "pending_reason": case["pending_reason"],
                    "violation_count": len(violations),
                },
            )
        else:
            case["status"] = "PASS"
            case["violations"] = []
            case["pending_reason"] = None

        case["evaluated_at"] = datetime.utcnow().isoformat()
        return case

    # =========================================================
    # Audit per rule (normalized)
    # =========================================================
    def _audit_rule(
        self,
        case_id: str,
        rule_id: str,
        rule_name: str,
        case: Dict[str, Any],
        violations: List[Dict[str, Any]],
    ) -> None:
        self._audit(
            case_id,
            "RULE_EVALUATED",
            {
                "rule_id": rule_id,
                "rule_name": rule_name,
                "result": "FAIL" if violations else "PASS",
                "violations": violations,
            },
        )

    # =========================================================
    # RULE IMPLEMENTATIONS (schema-aligned)
    # =========================================================
    def _check_price_deviation(self, case: Dict[str, Any]) -> List[Dict[str, Any]]:
        po = case.get("po") or {}
        contract = case.get("contract") or {}

        po_price = po.get("unit_price")
        contract_price = contract.get("unit_price")
        qty = po.get("quantity", 0)

        if not po_price or not contract_price:
            return []

        delta_pct = ((po_price - contract_price) / contract_price) * 100
        tolerance = self.policy.get("price_deviation", {}).get("tolerance_pct", 0)

        if delta_pct <= tolerance:
            return []

        delta_amount = (po_price - contract_price) * qty
        high_pct = self.policy.get("price_deviation", {}).get("high_pct", 999999)

        return [{
            "rule_id": "R-01",
            "rule_name": "Price deviation vs contract",
            "severity": "HIGH" if delta_pct > high_pct else "MEDIUM",
            "delta_pct": round(delta_pct, 2),
            "delta_amount": round(delta_amount, 2),
        }]

    def _check_amount_threshold(self, case: Dict[str, Any]) -> List[Dict[str, Any]]:
        amount = float(case.get("amount_total", 0) or 0)
        threshold = float(self.policy.get("amount_threshold", {}).get("cfo_approval", 0))

        if amount > threshold:
            return [{
                "rule_id": "R-02",
                "rule_name": "Amount exceeds approval threshold",
                "severity": "MEDIUM",
                "amount": amount,
            }]
        return []

    def _check_vendor_mismatch(self, case: Dict[str, Any]) -> List[Dict[str, Any]]:
        vendor_id = case.get("vendor_id")
        contract_vendor_id = (case.get("contract") or {}).get("vendor_id")

        if vendor_id and contract_vendor_id and vendor_id != contract_vendor_id:
            return [{
                "rule_id": "R-03",
                "rule_name": "Vendor mismatch",
                "severity": "HIGH",
            }]
        return []

    def _check_contract_validity(self, case: Dict[str, Any]) -> List[Dict[str, Any]]:
        po_date = case.get("po_date")
        contract = case.get("contract") or {}

        if not po_date or not contract.get("valid_from") or not contract.get("valid_to"):
            return []

        try:
            po_d = date.fromisoformat(po_date)
            start = date.fromisoformat(contract["valid_from"])
            end = date.fromisoformat(contract["valid_to"])
        except Exception:
            return []

        if not (start <= po_d <= end):
            return [{
                "rule_id": "R-04",
                "rule_name": "Contract expired or not yet valid",
                "severity": "HIGH",
            }]
        return []

    # =========================================================
    # Pending reason (human readable)
    # =========================================================
    def _build_pending_reason(self, violations: List[Dict[str, Any]]) -> str:
        mapping = {
            "R-01": "ราคาสูงกว่าสัญญา",
            "R-02": "มูลค่าเกิน threshold",
            "R-03": "Vendor ไม่ตรงสัญญา",
            "R-04": "สัญญาหมดอายุหรือยังไม่ valid",
        }
        return " / ".join(mapping.get(v["rule_id"], v["rule_id"]) for v in violations)
