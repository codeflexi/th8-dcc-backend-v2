from __future__ import annotations

import asyncio
import json
from dataclasses import dataclass
from datetime import datetime, timezone
from hashlib import sha256
from typing import Any, Callable, Dict, Optional, Tuple, List


# -------------------------
# Types
# -------------------------
ActionFn = Callable[[dict, dict], Tuple[bool, dict]]  # (success, result_payload)


@dataclass
class OrchestrationJob:
    job_id: str
    case_id: str
    action_type: str
    action_payload: dict
    trigger_event_id: Optional[str] = None
    idempotency_key: Optional[str] = None
    attempts: int = 0
    created_at: str = datetime.now(timezone.utc).isoformat()


# -------------------------
# Helpers
# -------------------------
def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _stable_json(obj: Any) -> str:
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def make_idempotency_key(case_id: str, action_type: str, business_key: str, payload: dict) -> str:
    raw = f"{case_id}|{action_type}|{business_key}|{_stable_json(payload)}"
    return sha256(raw.encode("utf-8")).hexdigest()


def _safe_get(obj: Any, path: str, default=None):
    cur = obj
    for part in path.split("."):
        if isinstance(cur, dict) and part in cur:
            cur = cur[part]
        else:
            return default
    return cur


# -------------------------
# Mock Actions (Phase 4)
# -------------------------
def action_erp_hold_payment(case: dict, payload: dict) -> Tuple[bool, dict]:
    po_id = payload.get("po_id") or case.get("case_id")
    return True, {
        "message": "Payment placed on hold (mock)",
        "erp_ref": f"HOLD:{po_id}",
    }


def action_erp_release_payment(case: dict, payload: dict) -> Tuple[bool, dict]:
    po_id = payload.get("po_id") or case.get("case_id")
    return True, {
        "message": "Payment released (mock)",
        "erp_ref": f"RELEASE:{po_id}",
    }


DEFAULT_ACTION_REGISTRY: Dict[str, ActionFn] = {
    "ERP_HOLD_PAYMENT": action_erp_hold_payment,
    "ERP_RELEASE_PAYMENT": action_erp_release_payment,
}


# -------------------------
# Orchestrator
# -------------------------
class EmbeddedOrchestrator:
    """
    Phase 4 Embedded Orchestrator (SAFE VERSION)

    Fixes:
    - ❌ no infinite polling
    - ❌ no re-processing same events
    - ✅ cursor uses created_at
    - ✅ idempotency enforced via audit table
    """

    def __init__(
        self,
        case_repo: Any,
        audit_repo: Any,
        action_registry: Optional[Dict[str, ActionFn]] = None,
        poll_interval_sec: float = 2.0,
    ) -> None:
        self.case_repo = case_repo
        self.audit_repo = audit_repo
        self.action_registry = action_registry or DEFAULT_ACTION_REGISTRY
        self.poll_interval_sec = poll_interval_sec

        self._queue: asyncio.Queue[OrchestrationJob] = asyncio.Queue()
        self._stop = asyncio.Event()

        self._task_poll: Optional[asyncio.Task] = None
        self._task_worker: Optional[asyncio.Task] = None

        # FIX: cursor must be created_at (not time)
        self._since_ts: str = _utc_now()

    # -------------------------
    # Lifecycle
    # -------------------------
    def start(self) -> None:
        if self._task_poll or self._task_worker:
            return

        self._stop.clear()
        self._task_poll = asyncio.create_task(self._poll_loop(), name="orch_poll")
        self._task_worker = asyncio.create_task(self._worker_loop(), name="orch_worker")

    async def stop(self) -> None:
        self._stop.set()
        for t in [self._task_poll, self._task_worker]:
            if t:
                t.cancel()
        await asyncio.sleep(0)

        self._task_poll = None
        self._task_worker = None

    # -------------------------
    # Poll loop (SAFE)
    # -------------------------
    async def _poll_loop(self) -> None:
        while not self._stop.is_set():
            try:
                events = self._list_events_since(self._since_ts)

                if events:
                    # FIX: advance cursor by created_at
                    max_ts = max(e.get("created_at") for e in events if e.get("created_at"))
                    self._since_ts = max_ts

                    for ev in events:
                        await self._derive_jobs_from_event(ev)

            except Exception as e:
                self._emit_audit(
                    case_id=None,
                    event_type="ORCHESTRATOR_ERROR",
                    actor="orchestrator",
                    payload={"error": str(e)},
                )

            await asyncio.sleep(self.poll_interval_sec)

    # -------------------------
    # Worker
    # -------------------------
    async def _worker_loop(self) -> None:
        while not self._stop.is_set():
            job: OrchestrationJob = await self._queue.get()
            try:
                await self._execute_job(job)
            finally:
                self._queue.task_done()

    # -------------------------
    # Event → Job (Phase 4 rules)
    # -------------------------
    async def _derive_jobs_from_event(self, ev: dict) -> None:
        event_type = ev.get("event_type")
        case_id = ev.get("case_id")
        payload = ev.get("payload") or {}

        if not case_id:
            return

        # FIX: align with your audit events
        if event_type == "CASE_PENDING":
            await self.enqueue_action(
                case_id=case_id,
                action_type="ERP_HOLD_PAYMENT",
                action_payload={"po_id": payload.get("po_id")},
                trigger_event_id=ev.get("id"),
                business_key=payload.get("po_id") or case_id,
            )

        if event_type == "DECISION_MADE":
            decision = (payload.get("decision") or "").upper()
            if decision in ("APPROVE", "APPROVE_WITH_EXCEPTION"):
                await self.enqueue_action(
                    case_id=case_id,
                    action_type="ERP_RELEASE_PAYMENT",
                    action_payload={"po_id": payload.get("po_id")},
                    trigger_event_id=ev.get("id"),
                    business_key=payload.get("po_id") or case_id,
                )

    # -------------------------
    # Enqueue
    # -------------------------
    async def enqueue_action(
        self,
        case_id: str,
        action_type: str,
        action_payload: dict,
        trigger_event_id: Optional[str],
        business_key: str,
    ) -> None:
        job_id = sha256(f"{case_id}|{action_type}|{_utc_now()}".encode()).hexdigest()[:16]
        idem_key = make_idempotency_key(case_id, action_type, business_key, action_payload)

        job = OrchestrationJob(
            job_id=job_id,
            case_id=case_id,
            action_type=action_type,
            action_payload=action_payload,
            trigger_event_id=trigger_event_id,
            idempotency_key=idem_key,
        )
        await self._queue.put(job)

    # -------------------------
    # Execute job
    # -------------------------
    async def _execute_job(self, job: OrchestrationJob) -> None:
        case = self.case_repo.get_case(job.case_id)
        if not case:
            return

        # FIX: idempotency via audit repo
        if self.audit_repo.has_action_success(job.case_id, job.action_type, job.idempotency_key):
            return

        self._emit_audit(
            case_id=job.case_id,
            event_type="ACTION_REQUESTED",
            actor="orchestrator",
            payload={
                "action_type": job.action_type,
                "job_id": job.job_id,
                "idempotency_key": job.idempotency_key,
            },
        )

        fn = self.action_registry.get(job.action_type)
        if not fn:
            return

        ok, result = fn(case, job.action_payload)

        self._emit_audit(
            case_id=job.case_id,
            event_type="ACTION_SUCCEEDED" if ok else "ACTION_FAILED",
            actor="orchestrator",
            payload={
                "action_type": job.action_type,
                "job_id": job.job_id,
                "idempotency_key": job.idempotency_key,
                "result": result,
            },
        )

    # -------------------------
    # Audit emit (aligned with SupabaseAuditRepository)
    # -------------------------
    def _emit_audit(self, case_id: Optional[str], event_type: str, actor: str, payload: dict) -> None:
        if not self.audit_repo:
            return
        self.audit_repo.append_event(
            case_id=case_id,
            event_type=event_type,
            actor=actor,
            payload=payload,
        )

    # -------------------------
    # Event reader
    # -------------------------
    def _list_events_since(self, since_ts: str) -> List[dict]:
        if not self.audit_repo:
            return []
        return self.audit_repo.list_events_since(since_ts)
